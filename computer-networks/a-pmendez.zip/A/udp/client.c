/*-------------------------------------------------------------*/
/* client.c - UDP.                         */
/*-------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <string.h>
#include <sys/types.h>
#include "inet.h"

#define MAX 100

int get_response(void);
void intHandler(int dummy);

int                 sockfd;
struct sockaddr_in  cli_addr, serv_addr;
char                s[MAX];      /* array to hold output */
int                 response;    /* user response        */
int                 nread;       /* number of characters */
int					servlen;     /* length of server addr*/
char				request;

main(int argc, char **argv)
{
    signal(SIGINT,intHandler);

    /* Set up the address of the server to be contacted. */
    memset((char *) &serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family      = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(SERV_HOST_ADDR);
    serv_addr.sin_port        = htons(SERV_UDP_PORT);

    /* Set up the address of the client. */
    memset((char *) &cli_addr, 0, sizeof(cli_addr));
    cli_addr.sin_family      = AF_INET;
    cli_addr.sin_addr.s_addr = htonl(0);
    cli_addr.sin_port        = htons(0);

    /* Create a socket (an endpoint for communication). */
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("client: can't open datagram socket");
        exit(0);
    }

    /* Bind the client's socket to the client's address */
    if (bind(sockfd, (struct sockaddr *) &cli_addr, sizeof(cli_addr)) < 0) {
        perror("client: can't bind local address");
        exit(0);
    }

    /*printf("%s \n",inet_ntoa(cli_addr.sin_addr));*/

    /* Display the menu, read user's response, and send it to the server. */
    while((response = get_response()) != 4) {

        if (response < 1 || response > 4)
        {
            printf("\nPlease only input numbers 1-4\n");
            continue;
        }

        /* Send the user's response to the server. */
        servlen = sizeof(serv_addr);
        
        request = (char)('0' + response);

        /*request = (char)('0' + response);*/
        sendto (sockfd, (char *) &request, sizeof(request), 0,
                (struct sockaddr *) &serv_addr, servlen);

        /* Read the server's response. */
        nread = recvfrom(sockfd, s, MAX, 0,
                (struct sockaddr *) &serv_addr, &servlen);
        if (nread > 0) {
            printf("   %s\n", s);
        } else {
            printf("Nothing read. \n");
        }
    }
    exit(0);  /* Exit if response is 4  */
}

/* Display menu and retrieve user's response */
int get_response()
{
    int choice;
    char trash;

    printf("==================================================\n");
    printf("                   Menu: \n");
    printf("--------------------------------------------------\n");
    printf("                1. Current Time\n");
    printf("                2. PID of Server\n");
    printf("                3. Random number 1-20 (inclusive)\n");
    printf("                4. Quit (client only)\n") ;
    printf("-------------------------------------------------\n");
    printf("               Choice (1-4):");
    if(scanf("%d",&choice) !=1 )
    {
        /* If the user inputs a character instead of a number, 
         * scanf returnes 0 'items' consumed therefore the 
         * character stays in the buffer. Without that scanf below, 
         * it will cause an infinite loop because nothing is taking the
         * character off the buffer. I'm putting the character read in 
         * a trash variable and return a number outside of 1-4 that will 
         * make it get into the if statement that prints the options they can input*/
        scanf("%c", &trash);
        return(5);
    }
    else{
        printf("=================================================\n");
        return(choice);
    }
}

void intHandler(int dummy)
{
    request = (char)('0' + 0);
    sendto (sockfd, (char *) &request, sizeof(request), 0,
            (struct sockaddr *) &serv_addr, servlen);
    printf("\nGoodbye!\n");
    exit(0);
}

