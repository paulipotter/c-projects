### Description
This is a simple TCP client-server application where the client prints a menu with possible commands.
The command is sent to + executed on server. The client prints the reply.

## Instructions
1. Copy the files to your own directory.
2. Modify inet.h to reflect the host you are currently logged into.
  - **VIPER:** 129.130.10.43 
  - **COUGAR:** 129.130.10.39
  - Starter code: net2
  - Check to see if the selected port is in use by using the command: `netstat -an \| grep <port #>`
3. Compile the source code using the command: make.
4. Start the server in the background: `TCPserver &`
5. Start the client on the same or another host in the foreground: `TCPclient`
6. Server and client should kill themselves when you press `^C`
   
Note: Option 4 in the program only kills the client


