## Programming Assignment A
###### Paula Mendez - CIS 525 - Programming Assignment A
This is a simple client-server application where the client prints a menu with possible commands.
The command is sent to + executed on server. The client prints the reply.

#### Part A: 
* connectionless 
* using udp
* starter code: net2

#### Part C: 
* connection-oriented 
* using tcp
* starter code: net1

#### On both parts:
* Don't forget to change `inet.h` to the appropriate IP of the server where you are running `server.c`
* Find open ports by running `netstat -an \| grep <port#>`
* Code should be successfully able to handle any numbers or characters (and strings) outside of the 4 menu options and deliver an error message.
* when `^C` is pressed, the program *will* say goodbye and exit. Client and server should terminate themselves.

> Note: inet.h on both folders are set to cougar (129.130.10.39) or viper (129.130.10.43). I tested running the server on cougar and the client on viper and it works. 
**Please make sure to change the IP to the server you are planning to run server.c**
