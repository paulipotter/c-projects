### Description
I wasn't able to finish this assignment :(
I will profide a quick summary of the things asked 

### Client-Server chat server
- multiple clients should be able to connect to one sercer
- No duplicate names allowed (partially implemented)
- Notify when user joins or if first, say "you are the first user to join"
- implement chat directory service  
I had a very hard time understanding how to serialize information taken to server, and how the server differentiates a. a request to check an alias vs a message to be broadcasted and b. the different clients. 
Client server doesn't bind and that's ok because I chose to write more code than just have a working piece that's a tiny part of the code. please please read the code. The fact that there were limited office hours also made it a lot harder for me to figure it out things. I will try to implement different methods that take care parts of the different requirements.

## Instructions
1. Copy the files to your own directory.
2. Modify inet.h to reflect the host you are currently logged into.
  - **VIPER:** 129.130.10.43 
  - **COUGAR:** 129.130.10.39
  - Starter code: net2
  - Check to see if the selected port is in use by using the command: `netstat -an \| grep <port #>`
3. Run `chmod +x run_me.sh` to be able to run the bash script
  - `./run_me.sh`
  - The bash script will run make and fire up the server in the background and the client in the foreground
4. Alternatively, compile the source code using the command: make.
  - Start the server in the background: `TCPserver &`
  - Start the client on the same or another host in the foreground: `TCPclient`
  - Server and client should kill themselves when you press `^C`
   

