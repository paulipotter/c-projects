/*-------------------------------------------------------------*/
/* client.c - TCP.                                             */
/*-------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <ctype.h>
#include "inet.h"

#define MAX 256
#define NOT_VALID 0
#define VALID 1

int get_alias(void);
int readn(int, char *, int);
void intHandler(int dummy);

int                 sockfd;
struct sockaddr_in  serv_addr;
char                s[MAX];      /* array to hold output */
int                 response;    /* user response        */
int                 nread;       /* number of characters */
int                 iostatus;
char                message[MAX];    /* user message        */

struct              request {
    int             code;
    char            message[MAX];
};


main(int argc, char **argv)
{

    /* Set up the address of the server to be contacted. */
    memset((char *) &serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family      = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(SERV_HOST_ADDR);
    serv_addr.sin_port        = htons(SERV_TCP_PORT);


    signal(SIGINT,intHandler);

    /* Display the menu, read user's response, and send it to the server. */
    for( ; ;)
    {
    
        iostatus = get_alias() ;
        if (iostatus > 0)
        {
            continue;
        }
        else if (iostatus == 0)
        {

            /* Create a socket (an endpoint for communication). */
            if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
            perror("client: can't open stream socket");
            exit(1);
            }

            /* Connect to the server. */
            if (connect(sockfd, (struct sockaddr *) &serv_addr,
                        sizeof(serv_addr)) < 0) {
                perror("client: can't connect to server");
                exit(1);
            }

            printf("message is: %s", message);
            /* Send the user's message to the server. */
            write (sockfd, message, sizeof(message));

            /* Read the server's reply. */
            nread = readn (sockfd, s, MAX);
            if (nread > 0) {
                printf("   %s\n", s);
            } else {
                printf("Nothing read. \n");
            }
            response = 0;

    printf("==================================================\n");
    printf("enter your message: ");
    /* Ascii values between 65-90 and 97-122 inclusive */
    fgets(message, sizeof(message), stdin);

            close(sockfd);

        }
     
    }

}

/* Display menu and retrieve user's response */
int get_alias()
{
    int i, status;
    status = NOT_VALID;
    bool duplicate = true;
    while( status == NOT_VALID || duplicate == true){
        /* Ask for Alias until it's a valid one */
        if (status == NOT_VALID)
        {
            printf("==================================================\n");
            printf(" Please write the alias you want to use: ");
            /* Ascii values between 65-90 and 97-122 inclusive */
            fgets(message, sizeof(message), stdin);
            printf("==================================================\n");

            for(i=0; i < strlen(message); i++)
            {
                if(isalpha(message[i] || message[i] == ' '|| message[i] == '\0' || message[i] == '\n'))
                {
                    /* ignore ' ', '\n', '\0' */
                    status = VALID;
                    continue;
                }
                else if(isdigit(message[i])) {
                    /* anything else will stop checking string and will return a number that will display an error */
                    printf("\nPlease enter your username. Only A-Z and a-z allowed. No Symbols or numbers\n");
                    status = NOT_VALID;
                    break;
                } 
            } /* end for */
        }
        if( status = VALID )
        {
          /* Write to server to see if there's a duplicate */
          /* When we know that it's a 'valid' alias, we check with the server 
           * if it's a duplicate or not. When the server successfully registers the alias
           * it will also reply with a string that will either say "you are the first" 
           * or "you successfully joined" (not fully implemented)
           * write (sockfd, request, sizeof(request)); */

            nread = readn (sockfd, s, MAX);
            if (nread > 0) {
                printf("   %s\n", s);
            } else {
                printf("Nothing read. \n");
            }
        }
          /* alias is valid */

        }
    /* Break in the while loop means that the name passes the test for alpha numeric
     * now check for duplicates on server*/
    return(0);
}

/*
 * Read up to "n" bytes from a descriptor.
 * Use in place of read() when fd is a stream socket.
 */

    int
readn(fd, ptr, nbytes)
    register int	fd;
    register char	*ptr;
    register int	nbytes;
{
    int	nleft, nread;

    nleft = nbytes;
    while (nleft > 0) {
        nread = read(fd, ptr, nleft);
        if (nread < 0)
            return(nread);		/* error, return < 0 */
        else if (nread == 0)
            break;			/* EOF */

        nleft -= nread;
        ptr   += nread;
    }
    return(nbytes - nleft);		/* return >= 0 */
}

void intHandler(int dummy)
{
    printf("\nGoodbye!\n");
    exit(0);
}

