/*-------------------------------------------------------------*/
/* server.c - TCP.                                             */
/*-------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "inet.h"

#define MAX 1024
char check_alias(char alias[], char * list_of_names[]);


char                s[MAX];
char                line[MAX];

struct clients{
     struct sockaddr_in clientAddr;
     struct clients *next;
 };


/* got this excerpt of add client and send to all from https://stackoverflow.com/questions/41104762/sent-a-message-to-all-clients-with-c-programming
 * doesn't run */
 struct clients *add_client(struct sockaddr_in new_ClientAddr,struct clients *head)
 {

     struct clients *temp = head;
     int a = 1;
     if(head == NULL)
     {
         temp = (struct clients *)malloc(sizeof(struct clients));
         temp->clientAddr = new_ClientAddr;
         temp->next = NULL;
     }
     else
     {
         while(temp != NULL)
         {
         if(temp->clientAddr.sin_addr.s_addr == new_ClientAddr.sin_addr.s_addr)
         {
        a = 0;
        break;
        }
             temp = temp->next;
         }
         if(a == 1)
         {
             temp->next = (struct clients *)malloc(sizeof(struct clients));
            temp->next->clientAddr = new_ClientAddr;
            temp = temp->next;
            temp->next = NULL;
         }
         else{
             puts("Its already save");
         }
     }
     return head;
 }

void send_to_all(char msg[1023], struct sockaddr_in repliedClient, struct clients *head)
 {
    struct clients *temp = head;
    int clients_socket;
    int byte;
    clients_socket  = socket(AF_INET, SOCK_STREAM, 0);
        if(clients_socket == -1)
            perror("Error On Socket(send_to_all)");
    while(temp != NULL)
    {

       if(repliedClient.sin_addr.s_addr != temp->clientAddr.sin_addr.s_addr)
        {
            if(connect(clients_socket, (struct sockaddr *)&temp->clientAddr,
                                                sizeof(struct sockaddr)) == -1)
            {
                perror("Error on Connect(send_to_all)");
            byte = send(clients_socket, msg, strlen(msg), 0);
            printf("%s message send",msg);

            if(byte == -1)
                perror("Error on Send(send_to_all");
            else if(byte == 0)
                printf("Connection've been closed");

            temp = temp->next;
            }
        }
    }

 }

main(int argc, char **argv)
{
    int                 sockfd, newsockfd, childpid, temp_fd, struct_size,byte;
    unsigned int	clilen;
    struct sockaddr_in  new_cli_addr, serv_addr;
    char                request[MAX];
    struct clients *head = NULL;
    char text[MAX];

    /* Create communication endpoint */
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("server: can't open stream socket");
        exit(1);
    }

    /* Bind socket to local address */
    memset((char *) &serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family      = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port        = htons(SERV_TCP_PORT);

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
        perror("server: can't bind local address");
        exit(1);
    }

    listen(sockfd, 5);

    for ( ; ; ) {

        /* Accept a new connection request. */
        clilen = sizeof(new_cli_addr);
        newsockfd = accept(sockfd, (struct sockaddr *) &new_cli_addr, &clilen);
        if (newsockfd < 0) {
            perror("server: accept error");
            exit(1);
        }
        temp_fd = accept(sockfd , (struct sockaddr *)&new_cli_addr, &struct_size);
        if(temp_fd == -1)
            perror("Error on Accept");
        byte = recv(temp_fd, &text, sizeof(text), 0);
        if(byte == -1)
            perror("Error while trying to receive");
        else if(byte == 0)
            printf("Connection is closed\n");
        printf("%s", text);
        head = add_client(new_cli_addr, head);
        send_to_all(text, new_cli_addr, head);

        close(temp_fd);

    }
}

char check_alias(char alias[], char * list_of_names[])
{
    int length = sizeof(list_of_names)/sizeof(list_of_names[0]);
    int i;
    char message[MAX];

    for (i=0;i<length;i++)
    {
        if (strcmp(list_of_names, alias) == 0)
        {
            /* this is a duplicate, do not save. return with error message to client */
        /*break and leave the loop*/
          return("This is a duplicate, please use an unique name");
        }
    }
    /* reaching here means that no string matched the alias given by the client*/
    list_of_names[length+1] = alias;
    return("welcome to che chat");
}
