#!/bin/bash
make
echo " "
echo "****Welcome to Paula's Programming Assignment B****"
echo "              ****Part 3: TCP****"
echo " "
./TCPserver &
./TCPclient
