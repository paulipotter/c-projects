### Description
This is a simple UDP client-server application where the client requests the user for their name.
The name is  is sent to + executed on server. The client prints the reply.

## Instructions
1. Copy the files to your own directory.
2. Modify inet.h to reflect the host you are currently logged into.
  - **VIPER:** 129.130.10.43 
  - **COUGAR:** 129.130.10.39
  - Starter code: net2 + programming assignment a
  - Check to see if the selected ports are in use by using the command: `netstat -an \| grep <port #>`
3. Run `chmod +x run_me.sh` to be able to run the bash script
  - `./run_me.sh`
  - The bash script will run make and fire up the server in the background and the client in the foreground
4. Alternatively, compile the source code using the command: make.
  - Start the server in the background: `UDPserver &`
  - Start the client on the same or another host in the foreground: `UDPclient`
  - Server and client should kill themselves when you press `^C`
   
Note: I am running `system('pkill UDPserver')` to kill the server. It's not pretty but does the job.
