/*-------------------------------------------------------------*/
/* client.c - UDP.                                             */
/*-------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <ctype.h>
#include "inet.h"

#define MAX 256

int get_request(void);
void intHandler(int dummy);

int                 sockfd;
struct sockaddr_in  cli_addr, serv_addr;
char                s[MAX];      /* array to hold output */
char                request[256];    /* user request        */
int                 nread;       /* number of characters */
int					servlen;     /* length of server addr*/
int                 iostatus;

int main(int argc, char **argv)
{
    signal(SIGINT,intHandler);

    /* Set up the address of the server to be contacted. */
    memset((char *) &serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family      = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(SERV_HOST_ADDR);
    serv_addr.sin_port        = htons(SERV_UDP_PORT);

    /* Set up the address of the client. */
    memset((char *) &cli_addr, 0, sizeof(cli_addr));
    cli_addr.sin_family      = AF_INET;
    cli_addr.sin_addr.s_addr = htonl(0);
    cli_addr.sin_port        = htons(0);

    /* Create a socket (an endpoint for communication). */
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("client: can't open datagram socket");
        exit(0);
    }

    /* Bind the client's socket to the client's address */
    if (bind(sockfd, (struct sockaddr *) &cli_addr, sizeof(cli_addr)) < 0) {
        perror("client: can't bind local address");
        exit(0);
    }

    /*printf("%s \n",inet_ntoa(cli_addr.sin_addr));*/

    /* Display the menu, read user's request, and send it to the server. */
    for( ; ;) {

       iostatus = get_request() ;
        if (iostatus > 0)
        {
            printf("\nPlease enter your name. Only A-Z and a-z allowed. No Symbols or numbers\n");
            continue;
        }
        else if (iostatus == 0)
        {
            servlen = sizeof(serv_addr);
            
            /*request = (char)('0' + request);*/
            sendto (sockfd,  &request, sizeof(request), 0,
                    (struct sockaddr *) &serv_addr, servlen);
            //printf("read server request");
            
            /* Read the server's request. */
            nread = recvfrom(sockfd, s, MAX, 0,
                     (struct sockaddr *) &serv_addr, &servlen);
             if (nread > 0) {
                 printf("   %s\n", s);
             } else {
              //   printf("Nothing read. \n");
            }
        }
    }
}

/* Display menu and retrieve user's request */
int get_request()
{
    int i;

    printf("==================================================\n");
    printf(" Please insert your name: ");
    //Ascii values between 65-90 and 97-122 inclusive
    fgets(request, sizeof(request), stdin);
    //printf("%s\n", request);
    for(i=0; i < strlen(request); i++)
    {
        if(isalpha(request[i]))
        {
            request[i] = tolower(request[i]);
        }
        else {
            // ignore ' ', '\n', '\0'
            if(request[i] == ' '|| request[i] == '\0' || request[i] == '\n')    {   continue;   }
            //anything else will stop checking string and will return a number that will display an error
            if(isdigit(request[i])) {   return(1);  }
            else    {   return(2);  }
        }
    }
    return(0);
}

void intHandler(int dummy)
{
    system("pkill UDPserver");
    printf("\nGoodbye!\n");
    exit(0);
}

