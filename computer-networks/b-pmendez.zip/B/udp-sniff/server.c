/*-------------------------------------------------------------*/
/* server.c - UDP-SNIFF.                                       */
/*-------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "inet.h"

#define MAX 256
unsigned int get_sum(unsigned int n);

char                s[MAX];
char                line[MAX];
unsigned int        no_words, letter, final_sum, word_sum, letter_value;

int main(int argc, char **argv)
{
    int                 sockfd, clilen;
    struct sockaddr_in  cli_addr, serv_addr;
    char                request[MAX];
    const char del[2] = " ";


    /* Create communication endpoint */
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("server: can't open datagram socket");
        exit(1);
    }

    /* Bind socket to local address */
    memset((char *) &serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family      = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port        = htons(SERV2_UDP_PORT);

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
        perror("server: can't bind local address");
        exit(0);
    }

    for ( ; ; ) {

        /* Read the request from the client. */
        clilen = sizeof(cli_addr);
        recvfrom(sockfd, &request, sizeof(request), 0,
                (struct sockaddr *)&cli_addr, &clilen);


        /* Split sentence and parse it*/
        final_sum = no_words = word_sum = 0;

        char *token = strtok(request, del);

        /* While there are still have words in the sentence */
        while (token != NULL)
        {
            no_words+=1;

            /* Set word value to 0 */
            word_sum = 0;

            /* For every letter, add the value to have the word value */
            for(letter = 0; letter< strlen(token); letter++)
            {
                /* Ignore end of line, spaces and new lines*/
                if(token[letter] == ' ' || token[letter] == '\n' || token[letter] == '\0' )
                {
                    continue;
                }
                else{  
                    letter_value = (token[letter] - 97) % 10;             
                    word_sum += letter_value;
                }
            }

            /* Invoke get_sum until sum of words is single digit */
            while(word_sum > 9)
            {
                word_sum = get_sum(word_sum);
            }
            final_sum += word_sum;
            
            token = strtok(NULL, del);
            fflush(stdout);
            fflush(stdin);

        }

        /* Invoke get_sum until final_sum is single digit */
        while (final_sum > 9)
        {
            final_sum = get_sum(final_sum);
        }
       
        /* Switch case that matches the final digit to the appropriate string */
        switch(final_sum)
        {
            case 0:
                sprintf(line, "has a very strange name");
                strcpy(s, line);
                break;
            case 1:
                sprintf(line, "is ambitious, independent, and self-sufficient");
                strcpy(s, line);
                break;
            case 2:
                sprintf(line, "is supportive, diplomatic, and analytical");
                strcpy(s, line);
                break;
            case 3:
                sprintf(line, "is enthusiastic, optimistic, and fun-loving");
                strcpy(s, line);
                break;
            case 4:
                sprintf(line, "is practical, traditional, and serious");
                strcpy(s, line);
                break; 
            case 5:
                sprintf(line, "is adventurous, mercurial, and sensual");
                strcpy(s, line);
                break;
            case 6:
                sprintf(line, "is responsible, careful, and domestic");
                strcpy(s, line);
                break;
            case 7:
                sprintf(line, "is spiritual, eccentric, and a bit of a loner");
                strcpy(s, line);
                break;
            case 8:
                sprintf(line, "is money-oriented, decisive, and stern");
                strcpy(s, line);
                break; 
            case 9:
                sprintf(line, "is multi-talented, compassionate, and global");
                strcpy(s, line);
                break;
        };
                      
        /* Send the reply to the client. */
        sendto(sockfd, s, strlen(s)+1, 0,
            (struct sockaddr *) &cli_addr, clilen);

        }

}


/* got this excerpt from https://www.geeksforgeeks.org/program-for-sum-the-digits-of-a-given-number/ 
 * My Changes: added unsigned int since number will never be negative */
unsigned int get_sum(unsigned int n) 
{   
    unsigned int sum = 0; 
    while (n != 0) 
    { 
        sum = sum + n % 10; 
        n = n/10; 
    } 
    //printf("get_sum result is %d\n", sum);
    return sum; 
} 
