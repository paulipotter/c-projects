/*-------------------------------------------------------------*/
/* client.c - UDP.                         */
/*-------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <ctype.h>
#include "inet.h"

#define MAX 256

int get_request(void);
void intHandler(int dummy);

int                 sockfd;
struct sockaddr_in  cli_addr, serv_addr, sniff_addr;
char                s[MAX];          /* array to hold output */
char                request[256];    /* user request         */
char                new_request[256];    /*  modified request         */
int                 nread;           /* number of characters */
int					servlen, clilen;         /* length of server addr*/

int main(int argc, char **argv)
{

    /* Set up the address of the server to be contacted. */
    memset((char *) &serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family      = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(SERV_HOST_ADDR);
    serv_addr.sin_port        = htons(SERV_UDP_PORT);

    /* Set up the address of the sniffer. */
    memset((char *) &sniff_addr, 0, sizeof(sniff_addr));
    sniff_addr.sin_family      = AF_INET;
    sniff_addr.sin_addr.s_addr = htonl(0);
    sniff_addr.sin_port        = htons(0);

    /* Create a socket (an endpoint for communication). */
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("client: can't open datagram socket");
        exit(0);
    }

    /* Bind the client's socket to the sniffer's address */
    if (bind(sockfd, (struct sockaddr *) &sniff_addr, sizeof(sniff_addr)) < 0) {
        perror("client: can't bind local address");
        exit(0);
    }

    for( ; ;) {
        /* Read the request from the client. */
        clilen = sizeof(cli_addr);
        recvfrom(sockfd, &request, sizeof(request), 0,
                (struct sockaddr *)&cli_addr, &clilen);

        printf("hello from sniffer");

        /* add arrow and print */
        sprintf(new_request, "--> %s", request);
        print("%s\n", new_request);

            
        servlen = sizeof(serv_addr);
        /*request = (char)('0' + request);*/
        sendto (sockfd,  &request, sizeof(request), 0,
                (struct sockaddr *) &serv_addr, servlen);
        
        /* Read the server's request. */
        nread = recvfrom(sockfd, s, MAX, 0,
                    (struct sockaddr *) &serv_addr, &servlen);
            if (nread > 0) {
                /* add arrow and print */
                sprintf(new_request, "<-- %s", s);
                print("%s\n", new_request);
            } else {
                printf("nothing to read\n");
            }

            /* send info to client */
        /* Send the reply to the client. */
        sendto(sockfd, s, strlen(s)+1, 0,
            (struct sockaddr *) &cli_addr, clilen);

        } // end infinite loop
    
}

/* Display menu and retrieve user's request */
int get_request()
{
    int i;

    printf("==================================================\n");
    printf(" Please insert your name: ");
    //Ascii values between 65-90 and 97-122 inclusive
    fgets(request, sizeof(request), stdin);
    printf("%s\n", request);
    for(i=0; i < strlen(request); i++)
    {
        if(isalpha(request[i]))
        {
            request[i] = tolower(request[i]);
        }
        else {
            // ignore ' ', '\n', '\0'
            if(request[i] == ' '|| request[i] == '\0' || request[i] == '\n')    {   continue;   }
            //anything else will stop checking string and will return a number that will display an error
            if(isdigit(request[i])) {   return(1);  }
            else    {   return(2);  }
        }
    }
    return(0);
}

void intHandler(int dummy)
{
    char request = ('0' + 0);
    system("pkill UDPserver");
    sendto (sockfd, (char *) &request, sizeof(request), 0,
            (struct sockaddr *) &serv_addr, servlen);
    printf("\nGoodbye!\n");
    exit(0);
}

