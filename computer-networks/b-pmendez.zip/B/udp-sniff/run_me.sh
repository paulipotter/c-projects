#!/bin/bash
make
echo " "
echo "****Welcome to Paula's Programming Assignment B****"
echo "****This is Part 2 - client sniffer server****"
./UDPserver &
./UDPsniff &
./UDPclient
